#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {


    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
    vec3 position = Position;
    // Only PlotMines menu titles use this reserved colour at GUI title depth.
    // Their opaque canvas includes the icons, covering BOTH highlight passes.
    // Ordinary inventories, world text and item tooltips use the vanilla path.
    if (ProjMat[3][3] == 1.0 && abs(Position.z) < 0.01
            && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(255, 255, 254)))) {
        position.z += 320.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    // Pet screens have live, variable item models: only their backdrop is lifted.
    if (ProjMat[3][3] == 1.0 && abs(Position.z) < 0.01
            && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(255, 255, 253)))) {
        position.z += 50.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    // Live native titles must sit above their backdrop and below items/tooltips.
    if (ProjMat[3][3] == 1.0 && abs(Position.z) < 0.01
            && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(255, 255, 252)))) {
        position.z += 60.0;
        vertexColor = vec4(vec3(83.0, 86.0, 92.0) / 255.0, Color.a);
    }
    // Dynamic rank tiles must be above their canvas regardless of font-atlas batch order.
    if (ProjMat[3][3] == 1.0 && abs(Position.z) < 0.01
            && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(255, 255, 251)))) {
        position.z += 55.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);
}
