#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 position = Position;
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    // Only PlotMines menu titles use this reserved colour at GUI title depth.
    // Their opaque canvas includes the icons, covering BOTH highlight passes.
    // Ordinary inventories, world text and item tooltips use the vanilla path.
    if (ProjMat[3][3] == 1.0 && abs(Position.z) < 0.01
            && all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(255, 255, 254)))) {
        position.z += 320.0;
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);
    vertexDistance = fog_distance(Position, FogShape);
    texCoord0 = UV0;
}
